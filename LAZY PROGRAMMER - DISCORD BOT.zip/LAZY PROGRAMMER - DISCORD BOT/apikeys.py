botToken = "MTA5MTk0MzgyMjYwNDM3NDA0Ng.GtIzoN.7G7bHXpbRBpvWUGZj2Mh4X_ctcRfMYHp54qA4E"
owner_id = int("721017621335638071")
admin_channel_id = int("1092439437604032534")
member_join_id = int("756400874896621598")
member_leave_id = int("1092440712135589939")